package com.example.lenovo.instagramgradienttheme;

import android.app.ProgressDialog;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class Main2Activity extends AppCompatActivity {


    private EditText Name;
    private EditText Password;
    private TextView Info;
    private Button Login;
    private int counter=5;
    private TextView userRegister;
    private FirebaseAuth firebaseAuth;
    private ProgressDialog progressDialog;





    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        Name = (EditText) findViewById(R.id.etName);
        Password = (EditText) findViewById(R.id.etPassword);
        Info = (TextView) findViewById(R.id.tvinfo);
        Login = (Button) findViewById(R.id.btnLogin);
        userRegister = (TextView) findViewById(R.id.tvsign);

        Info.setText("No of attempts reamining:5");

        //firebse
        firebaseAuth= FirebaseAuth.getInstance();
         FirebaseUser user= firebaseAuth.getCurrentUser();

         //progressdialogue
        progressDialog=new ProgressDialog(this);


        if (user!=null){
             finish();
          startActivity(new Intent(Main2Activity.this, MapsActivity.class));//change the redirect activity once clinton has done
         }



        Login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                validate(Name.getText().toString(), Password.getText().toString());
            }
        });



        userRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Main2Activity.this,RegisterActivity.class));
            }
        });
    }






    private void validate(String userName, String userPassword) {

        progressDialog.setMessage("wait bitch waaaait! patience is key.");
        progressDialog.show();



        firebaseAuth.signInWithEmailAndPassword(userName,userPassword).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {

            if(task.isSuccessful()){
                progressDialog.dismiss();
                checkEmailVerication();
               // startActivity(new Intent(Main2Activity.this, Secondactivity.class));//change the redirect activity once clinton has done
            }
            else{
                progressDialog.dismiss();
                Toast.makeText(Main2Activity.this,"damn bruh,looks like we have an error or maybe its just you :)", Toast.LENGTH_LONG).show();
                counter--;
                Info.setText("no of attempts remaining:" + String.valueOf(counter));
                if (counter==0){
                    Login.setEnabled(false);
                }
            }


            }
        });

        /* if ((userName.equals("Admin") && (userPassword.equals("1234")))) {

            Intent second = new Intent(this, RegisterActivity.class);
            startActivity(second);
        }
        else
        {





        }*/
    }


    private void checkEmailVerication(){
        FirebaseUser firebaseUser =firebaseAuth.getInstance().getCurrentUser();
        Boolean emailflag = firebaseUser.isEmailVerified();
        if(emailflag){
            finish();
            startActivity(new Intent(Main2Activity.this, Secondactivity.class ));
        }
        else{
            Toast.makeText(this, "Verify your email", Toast.LENGTH_SHORT).show();
            firebaseAuth.signOut();
        }
    }

}
